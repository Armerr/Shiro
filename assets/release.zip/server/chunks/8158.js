"use strict";exports.id=8158,exports.ids=[8158],exports.modules={46011:(e,t,i)=>{function a(e,t){e.accDescr&&t.setAccDescription?.(e.accDescr),e.accTitle&&t.setAccTitle?.(e.accTitle),e.title&&t.setDiagramTitle?.(e.title)}i.d(t,{A:()=>a}),(0,i(38753).eW)(a,"populateCommonDb")},98158:(e,t,i)=>{i.d(t,{diagram:()=>W});var a=i(46011),l=i(24125),r=i(3839),s=i(38753),o=i(46723),n=i(47678),c=s.vZ.pie,p={sections:new Map,showData:!1,config:c},d=p.sections,g=p.showData,u=structuredClone(c),x=(0,s.eW)(()=>structuredClone(u),"getConfig"),f=(0,s.eW)(()=>{d=new Map,g=p.showData,(0,s.ZH)()},"clear"),h=(0,s.eW)(({label:e,value:t})=>{d.has(e)||(d.set(e,t),s.cM.debug(`added new section: ${e}, with value: ${t}`))},"addSection"),m=(0,s.eW)(()=>d,"getSections"),w=(0,s.eW)(e=>{g=e},"setShowData"),S=(0,s.eW)(()=>g,"getShowData"),T={getConfig:x,clear:f,setDiagramTitle:s.g2,getDiagramTitle:s.Kr,setAccTitle:s.GN,getAccTitle:s.eu,setAccDescription:s.U$,getAccDescription:s.Mx,addSection:h,getSections:m,setShowData:w,getShowData:S},$=(0,s.eW)((e,t)=>{(0,a.A)(e,t),t.setShowData(e.showData),e.sections.map(t.addSection)},"populateDb"),y={parse:(0,s.eW)(async e=>{let t=await (0,o.Qc)("pie",e);s.cM.debug(t),$(t,T)},"parse")},D=(0,s.eW)(e=>`
  .pieCircle{
    stroke: ${e.pieStrokeColor};
    stroke-width : ${e.pieStrokeWidth};
    opacity : ${e.pieOpacity};
  }
  .pieOuterCircle{
    stroke: ${e.pieOuterStrokeColor};
    stroke-width: ${e.pieOuterStrokeWidth};
    fill: none;
  }
  .pieTitleText {
    text-anchor: middle;
    font-size: ${e.pieTitleTextSize};
    fill: ${e.pieTitleTextColor};
    font-family: ${e.fontFamily};
  }
  .slice {
    font-family: ${e.fontFamily};
    fill: ${e.pieSectionTextColor};
    font-size:${e.pieSectionTextSize};
    // fill: white;
  }
  .legend text {
    fill: ${e.pieLegendTextColor};
    font-family: ${e.fontFamily};
    font-size: ${e.pieLegendTextSize};
  }
`,"getStyles"),C=(0,s.eW)(e=>{let t=[...e.entries()].map(e=>({label:e[0],value:e[1]})).sort((e,t)=>t.value-e.value);return(0,n.ve8)().value(e=>e.value)(t)},"createPieArcs"),W={parser:y,db:T,renderer:{draw:(0,s.eW)((e,t,i,a)=>{s.cM.debug("rendering pie chart\n"+e);let o=a.db,c=(0,s.nV)(),p=(0,l.Rb)(o.getConfig(),c.pie),d=(0,r.P)(t),g=d.append("g");g.attr("transform","translate(225,225)");let{themeVariables:u}=c,[x]=(0,l.VG)(u.pieOuterStrokeWidth);x??=2;let f=p.textPosition,h=(0,n.Nb1)().innerRadius(0).outerRadius(185),m=(0,n.Nb1)().innerRadius(185*f).outerRadius(185*f);g.append("circle").attr("cx",0).attr("cy",0).attr("r",185+x/2).attr("class","pieOuterCircle");let w=o.getSections(),S=C(w),T=[u.pie1,u.pie2,u.pie3,u.pie4,u.pie5,u.pie6,u.pie7,u.pie8,u.pie9,u.pie10,u.pie11,u.pie12],$=(0,n.PKp)(T);g.selectAll("mySlices").data(S).enter().append("path").attr("d",h).attr("fill",e=>$(e.data.label)).attr("class","pieCircle");let y=0;w.forEach(e=>{y+=e}),g.selectAll("mySlices").data(S).enter().append("text").text(e=>(e.data.value/y*100).toFixed(0)+"%").attr("transform",e=>"translate("+m.centroid(e)+")").style("text-anchor","middle").attr("class","slice"),g.append("text").text(o.getDiagramTitle()).attr("x",0).attr("y",-200).attr("class","pieTitleText");let D=g.selectAll(".legend").data($.domain()).enter().append("g").attr("class","legend").attr("transform",(e,t)=>"translate(216,"+(22*t-22*$.domain().length/2)+")");D.append("rect").attr("width",18).attr("height",18).style("fill",$).style("stroke",$),D.data(S).append("text").attr("x",22).attr("y",14).text(e=>{let{label:t,value:i}=e.data;return o.getShowData()?`${t} [${i}]`:t});let W=512+Math.max(...D.selectAll("text").nodes().map(e=>e?.getBoundingClientRect().width??0));d.attr("viewBox",`0 0 ${W} 450`),(0,s.v2)(d,450,W,p.useMaxWidth)},"draw")},styles:D}}};